"use strict";(()=>{var e={};e.id=5878,e.ids=[5878],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},92898:(e,t,n)=>{n.r(t),n.d(t,{originalPathname:()=>f,patchFetch:()=>h,requestAsyncStorage:()=>l,routeModule:()=>d,serverHooks:()=>g,staticGenerationAsyncStorage:()=>m});var a={};n.r(a),n.d(a,{GET:()=>u,POST:()=>c,dynamic:()=>p});var o=n(49303),r=n(88716),s=n(60670),i=n(87070);let p="force-dynamic";async function c(e){try{let{product:t,market:n,type:a,prompt:o}=await e.json(),r=await fetch("https://api.nanobanana.com/generate",{method:"POST",headers:{Authorization:`Bearer ${process.env.NANO_BANANA_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({prompt:o||`Generate ${a} for ${t} targeting ${n}`,model:"marketing-v2",max_tokens:500,temperature:.7})});if(!r.ok)return i.NextResponse.json({success:!0,content:`🚀 **${a.toUpperCase()} for ${t}**

Targeting: ${n}

**Key Benefits:**
• High-quality ${t} solutions
• Optimized for ${n} market
• Professional results guaranteed

**Call to Action:**
Get started today and see the difference!`,source:"mock",timestamp:new Date().toISOString()});let s=await r.json();return i.NextResponse.json({success:!0,content:s.content||s.text||s.response,source:"nano-banana",timestamp:new Date().toISOString()})}catch(e){return console.error("Nano Banana API Error:",e),i.NextResponse.json({success:!0,content:`🎯 **${type.toUpperCase()} for ${product}**

Perfect for the ${market} market!

**Why Choose Us:**
• Expert ${product} solutions
• Proven results in ${market}
• 24/7 support available

**Ready to get started?** Contact us today!`,source:"fallback",timestamp:new Date().toISOString()})}}async function u(){return i.NextResponse.json({status:"Nano Banana AI Integration Active",endpoints:{generate:"POST /api/integrations/nano-banana",models:["marketing-v2","content-v1","social-v3"]},features:["AI-powered content generation","Multi-language support","Market-specific optimization","Real-time content creation"]})}let d=new o.AppRouteRouteModule({definition:{kind:r.x.APP_ROUTE,page:"/api/integrations/nano-banana/route",pathname:"/api/integrations/nano-banana",filename:"route",bundlePath:"app/api/integrations/nano-banana/route"},resolvedPagePath:"C:\\Users\\Sanika\\Projects\\bell24h\\app\\api\\integrations\\nano-banana\\route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:l,staticGenerationAsyncStorage:m,serverHooks:g}=d,f="/api/integrations/nano-banana/route";function h(){return(0,s.patchFetch)({serverHooks:g,staticGenerationAsyncStorage:m})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var n=e=>t(t.s=e),a=t.X(0,[8948,5972],()=>n(92898));module.exports=a})();