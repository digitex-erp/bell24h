// Tailwind v4 + Next.js
module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},
  },
};